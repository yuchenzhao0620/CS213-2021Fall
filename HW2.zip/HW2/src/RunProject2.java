/**
 * RunProject2 class
 * This class will start the project.
 *
 * @author yuchenzhao yz1116, Jinrui Li jl2340
 */
public class RunProject2 {
    public static void main(String args[]){
        System.out.println("Tuition Manager starts running.");
        TuitionManager start = new TuitionManager();
        start.run();
    }
}