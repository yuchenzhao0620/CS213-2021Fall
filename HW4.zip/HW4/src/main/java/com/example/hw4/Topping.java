package com.example.hw4;

/**
 * An enum class about toppings
 *
 * @author YuchenZhao yz1116, Jinrui Li, jl2340
 */
public enum Topping {
    Chicken, Beef, Ham, Pineapple, BlackOlives, Cheese, Sausage, GreenPepper, Onion, Pepperoni, Mushroom
}
