package com.example.hw4;

/**
 * An enum class about size
 *
 * @author YuchenZhao yz1116, Jinrui Li, jl2340
 */
public enum Size {
    Small, Medium, Large
}
